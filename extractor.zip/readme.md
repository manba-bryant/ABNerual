# usage

1. use the venv as the py3 interprrter

2. modify the path in batch_run.py and preprocessing_ida.py->main()
   
3. run "batch_run.py path/to/target_elf"

\* test.py for have a view in the acfg 