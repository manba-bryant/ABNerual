# coding:utf-8
import os
import subprocess
import glob
import time
import argparse

# 使用 Wine 执行 IDA 的路径
IDA_PATH = "path/to/IDA-Pro-7.7/ida64.exe"
PLUGIN_PATH = "path/to/ABNeural/extractor/preprocessing_ida.py"  # 必须是绝对路径
DST_PATH = "path/to/ABNeural/target"

def parse_arguments():
    parser = argparse.ArgumentParser(description="Batch run IDA Pro on multiple ELF files.")
    parser.add_argument("elf_path", type=str, help="The specific ELF file or directory containing ELF files to process.")
    return parser.parse_args()

def main():
    args = parse_arguments()

    # 如果传入的是一个文件夹，则获取该文件夹下的所有文件
    if os.path.isdir(args.elf_path):
        ELF_PATH = glob.glob(os.path.join(args.elf_path, "*"))
    else:
        # 如果传入的是一个具体的文件路径
        ELF_PATH = [args.elf_path]

    print(ELF_PATH)

    core_num = 2  # 并行的个数，或者电脑有几个核心
    start = 0

    for elf in ELF_PATH:
        if elf.endswith(".i64"):
            continue
        # 准备通过 Wine 运行 IDA 的命令
        #cmd = f"wine {IDA_PATH} -c -A -S{PLUGIN_PATH} {elf}"
        cmd = f"wine {IDA_PATH} -c -S{PLUGIN_PATH} {elf}"
        print(cmd)

        if start >= core_num:
            finish = len(os.listdir(DST_PATH))
            while start - core_num >= finish:
                time.sleep(1)
                finish = len(os.listdir(DST_PATH))
                print(start, finish)

        # 使用 subprocess 运行命令
        subprocess.Popen(cmd, shell=True)
        start += 1

if __name__ == "__main__":
    main()

